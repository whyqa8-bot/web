# Primacarts WebView

Upload `primacarts-webview.zip` dan `.github/workflows/android.yml` ke GitHub. Workflow akan mengekstrak ZIP lalu membuild APK otomatis.
